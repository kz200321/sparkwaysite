package sparkwayv2;
public class Member {
	private String first_name, last_name, username, password, contact, address;

	public Member() {
		super();
	}

	public Member(String first_name, String last_name, String username, String password, String contact,
			String address) {
		super();
		this.first_name = first_name;
		this.last_name = last_name;
		this.username = username;
		this.password = password;
		this.contact = contact;
		this.address = address;
	}
	
	 public String getFirstName() {
	        return first_name;
	    }
	    public void setFirstName(String firstName) {
	        this.first_name = firstName;
	    }
	    public String getLastName() {
	        return last_name;
	    }
	    public void setLastName(String lastName) {
	        this.last_name = lastName;
	    }
	    public String getUsername() {
	        return username;
	    }
	    public void setUsername(String username) {
	        this.username = username;
	    }
	    public String getPassword() {
	        return password;
	    }
	    public void setPassword(String password) {
	        this.password = password;
	    }
	    public String getAddress() {
	        return address;
	    }
	    public void setAddress(String address) {
	        this.address = address;
	    }
	    public String getContact() {
	        return contact;
	    }
	    public void setContact(String contact) {
	        this.contact = contact;
	    }
}
