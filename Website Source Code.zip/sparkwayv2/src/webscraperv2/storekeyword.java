package webscraperv2;

public class storekeyword {
	private String searchJob;
	private String searchJobLocation;

	public storekeyword() {
		super();
	}

	public storekeyword( String searchJob, String searchJobLocation) {
		super();
		this.searchJob = searchJob;
		this.searchJobLocation = searchJobLocation;
	

	}
	
	
	

	

	public String getKeyword() {
	        return searchJob;
	    }
	    public void setKeyword(String searchJob) {
	        this.searchJob = searchJob;
	    }
	    
	    public String getKeywordLocation() {
	        return searchJobLocation;
	    }
	    public void setKeywordLocation(String searchJobLocation) {
	        this.searchJobLocation = searchJobLocation;
	    }
	    
	  
	    
	   
	
}

