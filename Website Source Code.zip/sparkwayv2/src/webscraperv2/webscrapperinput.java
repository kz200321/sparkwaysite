package webscraperv2;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;

import javax.swing.text.html.HTML;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class webscrapperinput {
	




	
	 
		
	
		
		public static final String CAREER_SEARCH_URL = "https://www.careerbuilder.com/jobs";
		public static final String INDEED_SEARCH_URL = "https://www.indeed.com/jobs";
		public static final String LINKEDIN_SEARCH_URL = "https://www.linkedin.com/jobs/search";
	
	
		

		
		
		
		public void scrapperinput(String searchJob, String searchjobLocation) throws IOException, SQLException {
			//Taking search term input from console
		
			String keyWordGoogle = (searchJob + " " + "Jobs" + " " + searchjobLocation).replace(" ", "+");
			String keyWordIndeedWhat = (searchJob.replace(" ", "+"));
					String keyWordIndeedWhere = (searchjobLocation.replace(" ", "+"));
			
					
					
			String keyWordLinkedIn = (searchJob).replace(" ", "%20");
			String keyWordLinkedInWhere = (searchjobLocation).replace(" ", "%2C%20");
					
				
				
					webscrapperselect selectClass= new webscrapperselect();
				String dbKey = searchJob + searchjobLocation;
			
		
			
			
			
			ArrayList<String>indeedListingsTitleArray = new ArrayList<String>();
			ArrayList<String>indeedListingsSummaryArray = new ArrayList<String>();
			ArrayList<String>indeedListingsCompaniesArray = new ArrayList<String>();
			
			ArrayList<String>careerListingsTitleArray = new ArrayList<String>();
			ArrayList<String>careerListingsSummaryArray = new ArrayList<String>();
			ArrayList<String>careerListingsCompaniesArray = new ArrayList<String>();
			
			ArrayList<String>linkedListingsTitleArray = new ArrayList<String>();
			ArrayList<String>linkedListingsSummaryArray = new ArrayList<String>();
			ArrayList<String>linkedListingsCompaniesArray = new ArrayList<String>();
						//ArrayListConstructor constructor = new ArrayListConstructor();
			
		//	JobListArray = constructor.getList();
			
			int number = 0;
		
			JobTitleInsert insertClass = new JobTitleInsert();
			
			
			
			
			
			String indeedSearchURL = INDEED_SEARCH_URL + "?q=" + keyWordIndeedWhat + "&l=" + keyWordIndeedWhere + "&start" + number;
			String careerSearchURL = CAREER_SEARCH_URL + "?&keywords=" + keyWordIndeedWhat + "&location=" + keyWordIndeedWhere;
			String linkedSearchURL = LINKEDIN_SEARCH_URL +"?keywords=" + keyWordLinkedIn + "&location=" + keyWordLinkedInWhere;
			
			//without proper User-Agent, we will get 403 error
			
			Document doc2 = Jsoup.connect(indeedSearchURL).get();
			Document doc3 = Jsoup.connect(careerSearchURL).get();
			Document doc4 = Jsoup.connect(linkedSearchURL).get();
			
					//.userAgent("Mozilla/5.0").get();
			
			//below will print HTML data, save it to a file and open in browser to compare
			//System.out.println(doc.html());
			
			//If google search results HTML change the <h3 class="r" to <h3 class="r1"
			//we need to change below accordingly
			//Elements results = doc.getElementsByClass("LC20lb DKV0Md");
			//a[class=turnstileLink]
			//span[@class="company"]
			//a[class*=jobtitle]
			Elements IndeedJobTitle = doc2.select("a[class*=jobtitle]");
			Elements indeedJobSummary = doc2.select("div[class=summary]");
		Elements IndeedJobCompany = doc2.select("span[class=company]");
		
		Elements careerJobTitle = doc3.select("div[class=data-results-title dark-blue-text b]");
		Elements careerJobSummary = doc3.select("div[class=block show-mobile]");
		Elements careerJobCompany = doc3.select("div[class=data-details]");
		
		Elements linkedJobTitle = doc4.select("span[class=screen-reader-text]");
		Elements linkedJobSummary = doc4.select("p.job-result-card__snippet");
		Elements linkedJobCompany = doc4.select("h4[class=result-card__subtitle job-result-card__subtitle]");
			
			//Elements results2 = doc.select("div.r");3
			
			//LC20lb DKV0Md
			//h3.r > a
		 for(Element indeedJobTitles: IndeedJobTitle) {
				String indeedTitle = indeedJobTitles.text();
				indeedListingsTitleArray.add(indeedTitle);
				
			}
			
		
		
			
			for(Element indeedJobSummarys: indeedJobSummary) {
				String jobSummary = indeedJobSummarys.text();
				indeedListingsSummaryArray.add(jobSummary);
			}
			
			for(Element indeedJobCompanies: IndeedJobCompany) {
				String jobCompany = indeedJobCompanies.text();
				indeedListingsCompaniesArray.add(jobCompany);
			}
			
		
		
			
		for(Element careerJobTitles: careerJobTitle) {
			String careerTitle = careerJobTitles.text();
			careerListingsTitleArray.add(careerTitle);
			
		}
		
		for(Element careerJobSummaries: careerJobSummary) {
			String careerSummary = careerJobSummaries.text();
			careerListingsSummaryArray.add(careerSummary);
			
		}
		
		for(Element careerJobCompanies: careerJobCompany) {
			String careerCompany = careerJobCompanies.text();
			careerListingsCompaniesArray.add(careerCompany);
			
		}
		
		for(Element linkedJobTitles: linkedJobTitle) {
			String linkedTitle = linkedJobTitles.text();
			linkedListingsTitleArray.add(linkedTitle);
			
		}
		
		for(Element linkedJobSummaries: linkedJobSummary) {
			String linkedSummary = linkedJobSummaries.text();
			linkedListingsSummaryArray.add(linkedSummary);
			
		}
		
		for(Element linkedJobCompanies: linkedJobCompany) {
			String linkedCompany = linkedJobCompanies.text();
			linkedListingsCompaniesArray.add(linkedCompany);
			
		}
			
			
			System.out.println("Linked" +linkedListingsCompaniesArray);
			
			
			
			scrapper servletClass = new scrapper();
			
			
		
			
			
			
			
			
			JobSummaryInsert jobsummary = new JobSummaryInsert();
			JobTitleInsert insert = new JobTitleInsert();
			JobCompanyInsert company = new JobCompanyInsert();
			
			
			insert.inserttext(indeedListingsTitleArray, careerListingsTitleArray, linkedListingsTitleArray);
		jobsummary.inserttext(indeedListingsSummaryArray, careerListingsSummaryArray,linkedListingsSummaryArray);
		company.inserttext(indeedListingsCompaniesArray, careerListingsCompaniesArray, linkedListingsCompaniesArray);
		
		
			
			
			
			
			

		
			
			
			
		
			
			
			
		//	String resultv2 = "Text::" + results.text() ;
			//String resultv3 = results2.text();
		//	System.out.println(resultv2);
		//	System.out.print(resultv3);
		
		
		
		/*public static void main(String[] args) throws IOException {
			scrapperinput("java jobs");
		}*/
		
	
		}

	
		
}
