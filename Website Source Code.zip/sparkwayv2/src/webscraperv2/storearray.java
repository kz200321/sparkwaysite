package webscraperv2;

import java.util.ArrayList;

public class storearray {
	private ArrayList<String> GoogleJobListTitleArray;
	public storearray() {
		
	}
	public storearray(ArrayList<String> GoogleJobListTitleArray) {
		this.GoogleJobListTitleArray=GoogleJobListTitleArray;
	}

public  void setList(ArrayList<String> GoogleJobListTitleArray) {
	this.GoogleJobListTitleArray=GoogleJobListTitleArray;
}

public ArrayList<String> getList(){
	return GoogleJobListTitleArray;
	
}

}
