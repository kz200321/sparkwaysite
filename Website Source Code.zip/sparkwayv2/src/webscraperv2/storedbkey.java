package webscraperv2;

public class storedbkey {
	private String dbkey;
	
	
	
	
	public storedbkey() {
		super();
	}
	
	public storedbkey(String dbkey) {
		super();
		this.dbkey = dbkey;
	}

	public String getdbkey() {
        return dbkey;
    }
    public void setdbkey(String dbkey) {
        this.dbkey = dbkey;
    }
}
