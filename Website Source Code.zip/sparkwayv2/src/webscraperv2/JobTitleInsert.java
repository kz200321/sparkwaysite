package webscraperv2;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jobpost.storeinfo;

public class JobTitleInsert
{
	private String dburl="jdbc:mysql://database-sparkway.cbn3kxj3grli.us-east-1.rds.amazonaws.com/sparkwayv3";
	private String dbuname="egg";
	private String dbpassword="eggegg01";
	private String dbdriver="com.mysql.jdbc.Driver";
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		Connection con=null;
		try {
		con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return con;
	
	}
	
	public  String inserttext(ArrayList<String> indeedListingsTitleArray, ArrayList<String> careerListingsTitleArray, ArrayList<String> linkedListingsTitleArray) throws SQLException{
		//ArrayList<String> JobListArray, ArrayList<String> indeedListingsArray, ArrayList<String> zipListingsArray
	scrapper servletClass = new scrapper();
	

ArrayList<String> insertFinal = new ArrayList<String>();
insertFinal.addAll(careerListingsTitleArray);
insertFinal.addAll(indeedListingsTitleArray);
insertFinal.addAll(linkedListingsTitleArray);



		
		
		
	
loadDriver(dbdriver);
		
		Connection con=getConnection();
int tempNumb=0;
	System.out.println("ArrayList:" + insertFinal);
		for(int count = 0; count<insertFinal.size(); count++)
		{
		String temp = insertFinal.get(count);
			 PreparedStatement ps = con.prepareStatement("select jobTitle from indeedTest where jobTitle = ?");
			  ps.setString(1,temp);
			  ResultSet rs = ps.executeQuery();
			  if(rs.next()==true) {
				
				  System.out.println("alredy there");
			  }
			  else {
				  System.out.println("insert");
				  String sql="insert into indeedTest (jobTitle) values (?)";


				  try {
				  	PreparedStatement ps1=con.prepareStatement(sql);
				  ps1.setString(1, temp);
				  ps1.executeUpdate();
				  	
				  	

				  } catch (SQLException e) {
				  	// TODO Auto-generated catch block
				  	e.printStackTrace();
				    
				   
				  }
				
						
				}
			 
			
			  }
		
		
		
		
		
	String result = "hey";
		
		
		
		/*String sql2="insert into indeedJobs (JobTitle)" +  "values (?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql2);
			for(String list: indeedListingsArray) {
			ps.setString(1, list);
            ps.addBatch();

			}
			ps.executeBatch();
			
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = "data not entered";
		}
		
		String sql3="insert into zipJobs (JobTitle)" +  "values (?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql3);
			for(String list: zipListingsArray) {
			ps.setString(1, list);
            ps.addBatch();

			}
			ps.executeBatch();
			
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = "data not entered";
		}*/
		
		
	
		return result;
		
		
		
		
	}
	

	

}
