package webscraperv2;

public class storedbweb {
private String str1;

public storedbweb() {
	super();
}

public storedbweb(String str1) {
	super();
	this.str1 = str1;
}

public String getstr3() {
    return str1;
}
public void setstr3(String str1) {
    this.str1 = str1;
    
} 
}
