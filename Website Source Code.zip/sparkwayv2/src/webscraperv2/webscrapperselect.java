package webscraperv2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.sql.*;



public class webscrapperselect {
	private String dburl="jdbc:mysql://database-sparkway.cbn3kxj3grli.us-east-1.rds.amazonaws.com/sparkwayv3";
	private String dbuname="egg";
	private String dbpassword="eggegg01";
	private String dbdriver="com.mysql.jdbc.Driver";
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		Connection con=null;
		try {
		con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return con;
	
	}
	
	public  ArrayList<String> selecttext(String searchJob, String searchJobLocation){
		
	scrapper servletClass = new scrapper();
String key = searchJob + " " + searchJobLocation;
	
	System.out.println(key);
		
		
		
	
loadDriver(dbdriver);
		
		Connection con=getConnection();
		

		
		ArrayList<String> listing = new ArrayList<String >();
		ArrayList<String> listing2 = new ArrayList<String >();
			   String words = "%" + searchJob + "%";
			 
			   
			    String query = "SELECT  indeedTest.jobTitle, indeedTest2.JobDesc, indeedTest3.companyName FROM indeedTest, indeedTest2, indeedTest3 WHERE indeedTest.jobTitle like ? and indeedTest.id=indeedTest2.id and indeedTest.id = indeedTest3.id";
			 
			   
			    try{
			   	PreparedStatement ps = con.prepareStatement(query);
			  
			    ps.setString(1,words);
			    
			    ResultSet rs=ps.executeQuery();
			    
			    	while(rs.next())
			    	{
			    		String JobTitleSQL = rs.getString("jobTitle");
			    		String JobDescSQL = rs.getString("JobDesc");
			    		String JobCompSQL = rs.getString("companyName");
			    		
			    		
			    		 listing.add(JobTitleSQL);
			    	    listing.add(JobCompSQL);
			    	    listing.add(JobDescSQL);
			    	    
			    	   
			    	
			    	
			    
			    	   
			    	    
			    	    
			    	}
			    }
			    	
			    	 
			     catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			    
			  
			  
			  System.out.println("lmao:" + listing);
			return listing;
	
}
	
}
			   
	
		  
		
	
		
		
		
		
	

	
			  
