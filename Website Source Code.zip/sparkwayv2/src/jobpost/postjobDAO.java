package jobpost;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class postjobDAO {
	private String dburl="jdbc:mysql://database-sparkway.cbn3kxj3grli.us-east-1.rds.amazonaws.com/sparkwayv3";
	private String dbuname="egg";
	private String dbpassword="eggegg01";
	private String dbdriver="com.mysql.jdbc.Driver";
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		Connection con=null;
		try {
		con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return con;
	
	}
	
	public String insertjob(storeinfo storepost){
		
		
loadDriver(dbdriver);
		
		Connection con=getConnection();
		
		String sql="insert into job_list (UserID,JobDescription,Location,JobField)" +  "values (?,?,?,?);";
		String result="Data entered Successfully";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setString(1, storepost.getUserID());
			ps.setString(2, storepost.getJobfield());
			ps.setString(3, storepost.getLocation());
			ps.setString(4, storepost.getJobdesc());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result="Data not entered successfully";
		}
		return result;
		
		
	}
	
}
