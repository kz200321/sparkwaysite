package jobpost;

public class storeinfo {
	private String UserID, Jobfield, Location, Jobdesc;

	public storeinfo() {
		super();
	}

	public storeinfo(String UserID, String Jobfield, String Location, String Jobdesc) {
		super();
		this.UserID = UserID;
		this.Jobfield = Jobfield;
		this.Location = Location;
		this.Jobdesc = Jobdesc;
	}
	
	 public String getUserID() {
	        return UserID;
	    }
	    public void setUserID(String UserID) {
	        this.UserID = UserID;
	    }
	    public String getJobfield() {
	        return Jobfield;
	    }
	    public void setJobfield(String Jobfield) {
	        this.Jobfield = Jobfield;
	    }
	    public String getLocation() {
	        return Location;
	    }
	    public void setLocation(String Location) {
	        this.Location = Location;
	    }
	    public String getJobdesc() {
	        return Jobdesc;
	    }
	    public void setJobdesc(String Jobdesc) {
	        this.Jobdesc = Jobdesc;
	    }
}
