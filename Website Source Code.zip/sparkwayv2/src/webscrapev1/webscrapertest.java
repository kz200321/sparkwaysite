package webscrapev1;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class webscrapertest {
	private static final String url = "https://www.google.com/search?safe=active&authuser=1&sxsrf=ALeKk02zLRBucKqrxLOaz8Zii67Xz4ad1A:1593529292222&source=hp&ei=zFP7Xu-WCsSCytMPsLiq2As&q=java+jobs&oq=java+jobs&gs_lcp=CgZwc3ktYWIQAzIFCAAQsQMyAggAMgIIADICCAAyAggAMgIIADICCAAyAggAMgIIADICCAA6CAgAEOoCEI8BOgUIABCDAVDpEVi9KGC0KWgBcAB4AIABSogBmASSAQE5mAEAoAEBqgEHZ3dzLXdperABCg&sclient=psy-ab&uact=5&ibp=htl;jobs&sa=X&ved=2ahUKEwiz5vid56nqAhWwhXIEHee7COIQiYsCKAF6BAgJEBA#htivrt=jobs&htidocid=kqxTT8YHPEzwRP3JAAAAAA%3D%3D&fpstate=tldetail";
	
		
		private Map<String, String> items;
		
		public webscrapertest() {
			items = new HashMap<>();
		}
		

	
	public String scanItems(String text) {
		Document document =null;
		try {
			document = Jsoup.connect(url).get();
			
			
		} catch (IOException ignored) {
			// TODO Auto-generated catch block
			System.out.println("cant scan items");
			
		}
		Elements elements = document.getElementsByClass("Qk80Jf");
		
		for(Element element: elements) {
			 text = element.ownText().toString();
			System.out.println(text);
			
			
		}
		//Qk80Jf
		//BjJfJf PUpOsf
		return text;
	}
	
	
	
	//public static void main(String [] args) throws IOException {
		//scanItems();
	//}
}
