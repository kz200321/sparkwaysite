package webscrapev1;

public class webscrapGet {
	private String text;
	


	public webscrapGet() {
		super();
	}
	
	

	public webscrapGet(String text) {
		super();
		this.text = text;
	}
	 public String getText() {
	        return text;
	    }
	    public void setText(String text) {
	        this.text = text;
	    }

}