package login;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;
/**
 * Servlet implementation class loginservlet
 */
@WebServlet("/loginservlet")
public class loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest req, HttpServletResponse res)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String n1 = req.getParameter("username");
        String n2 = req.getParameter("password");
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        
        
        try {
        	boolean isLoggedIn = false;
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://database-sparkway.cbn3kxj3grli.us-east-1.rds.amazonaws.com/sparkwayv3","egg","eggegg01");
	        PreparedStatement ps = con.prepareStatement("select username,password from member WHERE username=? && password=?");
	        ps.setString(1,n1);
	        ps.setString(2,n2);
	        ResultSet rs = ps.executeQuery();
	        
	        if(rs.next())
	        {
	        	
	       
	            res.sendRedirect("dashboard.jsp");
	           isLoggedIn = true;
	            req.setAttribute("loggedIn",isLoggedIn );

	        }   
	       
	        else
	        {
	        	req.setAttribute("message", "Credentials Invalid");
	            req.getRequestDispatcher("login.jsp").forward(req, res);
	        }
	        
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        

}
        
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
