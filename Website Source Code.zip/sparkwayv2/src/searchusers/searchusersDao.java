package searchusers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import sparkwayv2.Member;

public class searchusersDao extends searchuser{
	private String dburl="jdbc:mysql://database-sparkway.cbn3kxj3grli.us-east-1.rds.amazonaws.com/sparkwayv3";
	private String dbuname="egg";
	private String dbpassword="eggegg01";
	private String dbdriver="com.mysql.jdbc.Driver";
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		Connection con=null;
		try {
		con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return con;
	
	}


	
	public String select(String search_user) {
		
		
		
		
		loadDriver(dbdriver);
		
		
		Connection con=getConnection();
		
	
		String lastName = null;
		String firstName = search_user;
		String username = null;
		String address = null;
		String contact = null;
		String Jobdesc = null;
		String JobField =null;
		String Location = null;
		
		String id = search_user;
		 
		
		
		
	
		  try(PreparedStatement ps=con.prepareStatement("SELECT member.last_name,member.address,member.username,member.contact,job_list.JobField,job_list.Location,job_list.JobDescription  FROM member,job_list WHERE ? = member.id and ?=job_list.UserID")){
			    ps.setString(1,search_user);
			    ps.setString(2,id);
			    
			    try(ResultSet rs=ps.executeQuery()){
			    	if(rs.next()){
			    		
			    	    lastName=rs.getString(1);
			    	    username=rs.getString(2);
			    	    address=rs.getString(3);
			    	    contact=rs.getString(4);
			    	    Jobdesc=rs.getString(5);
			    	    JobField=rs.getString(6);
			    	    Location=rs.getString(7);
			    	
			    	   
			    	   
			    	    
			    	}
			    }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  
		
		 
		
		 
        
		  String result = firstName + " " + lastName+ " " + username+ " " + address+ " " +contact+ " " + Jobdesc+ " " + JobField + " " + Location;
		
		
		return result;
		
		
	}
	
/*	public String selectId(String search_user_id) {
loadDriver(dbdriver);
		
	Connection con=getConnection();
	String JobField = null;
	String Location = null;
	String JobDescription = null;
	
	try(PreparedStatement ps=con.prepareStatement("SELECT JobField,Location,JobDescription  FROM job_list WHERE ? = UserID")){
	    ps.setString(1,search_user_id);
	    
	    try(ResultSet rs=ps.executeQuery()){
	    	while(rs.next()){
	    		
	    		JobField=rs.getString(1);
	    		Location=rs.getString(2);
	    		JobDescription=rs.getString(3);
	    		
	    	   
	    	
	    	   
	    	   
	    	    
	    	}
	    }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		String resultsid = " " + JobField+ " " + Location + " " + JobDescription;
	
		
		return resultsid;
		
	}*/

}
	
			

